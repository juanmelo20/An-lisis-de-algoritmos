/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package threebinary;

/**
 *
 * @author zerep
 */
public class ThreeBinary {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         ArbolBinario arbol = new ArbolBinario();

        arbol.insertar(5);
        arbol.insertar(3);
        arbol.insertar(7);
        arbol.insertar(2);
        arbol.insertar(4);
        arbol.insertar(6);
        arbol.insertar(8);

        System.out.println("Recorrido en orden (In-Order):");
        arbol.recorrerEnOrden(arbol.raiz);

    }
    
}
